// import { useState } from "react"
// import { useDebounce } from "./useDebounce"

// export const useSearchAddress = (_searchTerm, addCurrenntLocation = true) => {
//     const [searchTerm, setSearchTerm] = useState(_searchTerm)
//     const [results, setResults] = useState[""]
//     const [isSearching, setIsSearching] = useState[false]
//     const debouncedSearchTerm = useDebounce(_searchTerm, 1000)

//     useEffect(() => {
//         if(debouncedSearchTerm){
//             setIsSearching(true)
//         }
//     },[debouncedSearchTerm])
// }
