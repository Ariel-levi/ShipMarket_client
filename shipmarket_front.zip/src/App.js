<<<<<<< HEAD
import "./App.css";
import AppRoutes from "./appRoutes";
=======
import logo from './logo.svg';
import './App.css';
>>>>>>> 358ad85 (Initialize project using Create React App)

function App() {
  return (
    <div className="App">
<<<<<<< HEAD
      <AppRoutes />
=======
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
>>>>>>> 358ad85 (Initialize project using Create React App)
    </div>
  );
}

export default App;
